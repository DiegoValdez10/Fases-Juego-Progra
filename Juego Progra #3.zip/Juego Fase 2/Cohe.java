import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Cohe here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cohe extends Actor
{
    space thisGame;
    /**
     * Act - do whatever the Cohe wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        
        
        if(isTouching(Serpi.class))
        {
            removeTouching(Serpi.class);
            thisGame.lives--;
        }
                {
        GreenfootImage image = getImage();
        image.scale(100, 50);
        setImage(image);
        } 
    }
    public void end() 
    {
        
        
        if(isTouching(Serpi.class))
        {
            removeTouching(Serpi.class);
            thisGame.lives--;
        }
        
        if (thisGame.lives == 0){
        Greenfoot.setWorld(new GameOver());
        }
        
        
        
    } 
}

