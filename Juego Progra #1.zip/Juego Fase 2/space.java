import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class space here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class space extends World
{
    public static int score = 0;
    /**
     * Constructor for objects of class space.
     * 
     */
    public space()
    {    
        super(600, 400, 1); 
        Astro n1=new Astro();
        addObject(n1,50,300);
        crearserpi(10);
    }
    public void crearserpi(int numero){
      for(int i=0;i<numero;i++){
          Serpi c=new Serpi();
          int x=Greenfoot.getRandomNumber(getWidth());
          int y=Greenfoot.getRandomNumber(getHeight());
          addObject(c,x,y);
      }
    }
    private void prepare(){
        score = 0;
    }
        long lastAdded = System.currentTimeMillis();
    public void act()
    {
        
    showText("Punteo: " + score, 500,25 );

        
        
    long curTime  = System.currentTimeMillis();
    if (curTime >= lastAdded + 7000) 
    {
       crearserpi(5);
       lastAdded  = curTime;
    }
    
    }
}