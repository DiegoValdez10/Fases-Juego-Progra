import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class heroe here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Astro extends Actor
{
    space thisGame;
    /**
     * Act - do whatever the heroe wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
      moveAndTurn();
      eat();
      size();
    }
    public void moveAndTurn()  
    {
      if (Greenfoot.isKeyDown("a"))
      {
       setLocation(getX()-3,getY());
      }
      if (Greenfoot.isKeyDown("d"))
      {
          setLocation(getX()+3,getY());
      }  
       if (Greenfoot.isKeyDown("w"))
      {
            setLocation(getX(),getY()-3);
      }
      if (Greenfoot.isKeyDown("s"))
      {
         setLocation(getX(),getY()+3);
      } 

    }
    public void eat()
    {
      Actor Serpi;
      Serpi = getOneObjectAtOffset(0, 0, Serpi.class);
      if (Serpi != null)
      {
          World world;
          world = getWorld();
          world.removeObject(Serpi);
          thisGame.score += 4;
      }
    }
    
    public void size()
    {    
        GreenfootImage image = getImage();  
        image.scale(50, 50);
        setImage(image);
    }
    }

